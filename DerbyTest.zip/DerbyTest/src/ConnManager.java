import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConnManager {

	public final static String DRIVER_NAME="org.apache.derby.jdbc.ClientDriver";
	public final static String DB_URL="jdbc:derby://localhost:1527/C:/Databases/MyDatabase";

	
	public static Connection getConnection(){
		Connection con = null;
		try {
			Class.forName(DRIVER_NAME);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			con = DriverManager.getConnection(DB_URL);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return con;
	}
}
