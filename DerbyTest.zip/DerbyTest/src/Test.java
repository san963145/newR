import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.SQLException;


public class Test {
	
	public static void main(String[] args) {
		
		Connection conn=ConnManager.getConnection();
		try {
			conn.setAutoCommit(false);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}    	
		try {
			String sql = "CREATE TABLE MySchema.Books ( " +
					"Isbn INTEGER NOT NULL, " +
					"Title VARCHAR(50) NOT NULL, " +
					"Price DECIMAL(6,2) NOT NULL, " +
					"CONSTRAINT PK_Books PRIMARY KEY (Isbn) " +
					")";
			PreparedStatement statement = conn.prepareStatement(sql);			
			statement.executeUpdate();		
			statement.close();			
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
